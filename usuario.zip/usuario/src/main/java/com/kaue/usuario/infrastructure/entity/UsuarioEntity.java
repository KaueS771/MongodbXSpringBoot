package com.kaue.usuario.infrastructure.entity;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document(collection="usuario_entity")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UsuarioEntity {
    @Id
    private String id;
    private String nome;
    private String email;
    private LocalDateTime dataCadastro;
    private LocalDateTime dataatualizacao;

}
